import requests, json, re, html, os
from time import sleep
from telethon import TelegramClient, events, sync
from telethon.errors import SessionPasswordNeededError
from telethon.tl.functions.messages import GetBotCallbackAnswerRequest, GetHistoryRequest

if not os.path.exists ('dangeagle'):
	os.makedirs ('dangeagle')
head = {
	'user-agent' : 'Mozilla/5.0 (Linux; Android 8.1.0; CPH1905) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.110 Mobile Safari/537.36'
}
api_id = 3792902
api_hash = "b26f3191f2e409ae4c115d4f713ed1f7"
def main (phone, wallet, api_id, api_hash):
	head = {
		'user-agent' : 'Mozilla/5.0 (Linux; Android 8.1.0; CPH1905) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.110 Mobile Safari/537.36'
	}
	client = TelegramClient ("dangeagle/" + phone, api_id, api_hash)
	client.connect ()
	if not client.is_user_authorized ():
		try:
			client.send_code_request (phone)
			client.sign_in (phone, input ("Nhập code : "))
		except SessionPasswordNeededError:
			client.start (("Nhập 2FA : "))
	username = "@Dogecoin_click_bot"
	entity = client.get_entity (username)
	while True:
		client.send_message (entity, "/visit")
		sleep (3)
		mess = client (GetHistoryRequest (peer = entity, limit = 10, offset_date = None, offset_id = 0, add_offset = 0, min_id = 0, max_id = 0, hash = 0))
		message = mess.messages[0].message
		if "You will be redirected" in message:
			url = mess.messages[0].reply_markup.rows[0].buttons[0].url
			if "/vc/" in url:
				os.system ('termux-open-url {}'.format (url))
				sleep (20)
				url = url.replace ("/vc/","/visit/")
			response = requests.get (url, headers = head, timeout = 60000).text
			if "data-token" in response:
				token = response.split ('data-token="')[1].split ('"')[0]
				code = response.split ('data-code="')[1].split ('"')[0]
				time = response.split ('data-timer="')[1].split ('"')[0]
				url = "https://doge.click/reward"
				head = {
					'user-agent' : 'Mozilla/5.0 (Linux; Android 8.1.0; CPH1905) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.110 Mobile Safari/537.36',
					'referer':'https://doge.click/visit/' + code,
					'x-requested-with':'XMLHttpRequest'
				}
				sleep(eval(time))
				data = {
					'code':code,
					'token':token
				}
				res = requests.post (url, headers = head, data = data).json ()
				mess = client (GetHistoryRequest (peer = entity, limit = 10, offset_date = None, offset_id = 0, add_offset = 0, min_id = 0, max_id = 0, hash = 0))
				message = mess.messages[1].message
				if "You earned" in message:
					coin = message.split ("You earned ")[1].split (" DOGE for visiting a site!")[0]
					client.send_message (entity, "/balance")
					sleep (2)
					mess = client (GetHistoryRequest (peer = entity, limit = 10, offset_date = None, offset_id = 0, add_offset = 0, min_id = 0, max_id = 0, hash = 0))
					message = mess.messages[0].message
					if "Available" in message:
						total = message.split ("Available balance: ")[1].split (" DOGE")[0]
						print ('Nhận được {} DOGE | Tổng DOGE : {}'.format (coin, total))
				continue
			sleep (1.5)
			mess = client (GetHistoryRequest (peer = entity, limit = 10, offset_date = None, offset_id = 0, add_offset = 0, min_id = 0, max_id = 0, hash = 0))
			message = mess.messages[0].message
			if "Please stay on" in message:
				print ("Vui lòng đợi 10 giây", end = "\r")
				sleep (11)
				mess = client (GetHistoryRequest (peer = entity, limit = 10, offset_date = None, offset_id = 0, add_offset = 0, min_id = 0, max_id = 0, hash = 0))
				message = mess.messages[1].message
				if "You earned" in message:
					coin = message.split ("You earned ")[1].split (" DOGE for visiting a site!")[0]
					client.send_message (entity, "/balance")
					sleep (2)
					mess = client (GetHistoryRequest (peer = entity, limit = 10, offset_date = None, offset_id = 0, add_offset = 0, min_id = 0, max_id = 0, hash = 0))
					message = mess.messages[0].message
					if "Available" in message:
						total = message.split ("Available balance: ")[1].split (" DOGE")[0]
						print ('Nhận được {} DOGE | Tổng DOGE : {}'.format (coin, total))
			else:
				mess = client (GetHistoryRequest (peer = entity, limit = 10, offset_date = None, offset_id = 0, add_offset = 0, min_id = 0, max_id = 0, hash = 0))
				message = mess.messages[1].message
				if "You earned" in message:
					coin = message.split ("You earned ")[1].split (" DOGE for visiting a site!")[0]
					client.send_message (entity, "/balance")
					sleep (2)
					mess = client (GetHistoryRequest (peer = entity, limit = 10, offset_date = None, offset_id = 0, add_offset = 0, min_id = 0, max_id = 0, hash = 0))
					message = mess.messages[0].message
					if "Available" in message:
						total = message.split ("Available balance: ")[1].split (" DOGE")[0]
						print ('Nhận được {} DOGE | Tổng DOGE : {}'.format (coin, total))
		elif "Sorry, there are" in message:
			print ("Hết link visit, quay lại sau vài giờ")
			break
list = eval (open ("phone.txt", "r", encoding = "utf-8").read ())

wallet = input ('enter wallet')
while True:
	for info in list:
		main (info, wallet, api_id, api_hash)
